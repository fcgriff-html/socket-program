# CS475-Final

Rock Paper Scissors Transfer Protocol (RPSTP)

1 = Rock,
2 = Paper,
3 = Scissors
